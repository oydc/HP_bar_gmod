-- Полоска ХП для Garry's Mod
--  * твоя полоска внизу слева + стрелка (2 варианта) + иконка смерти (3 варианта)
--  * полоски над головами игроков, ботов и NPC (включая NextBot)
--  * настройки: меню Q -> Утилиты -> Пользователь -> "Полоска ХП"
--  Команды: hpbar_arrow_switch / чат !hparrow — переключить стрелку

-- ===================== КОНФИГ =====================
local CONFIG = {
    -- Если список НЕ пустой, скрипт работает только у перечисленных игроков,
    -- у остальных он полностью выключен. Вписывай SteamID или SteamID64.
    -- Свой ID узнаешь командой в консоли: hpbar_myid
    -- Пример: OnlyFor = { "STEAM_0:1:12345678", "76561198012345678" },
    OnlyFor = {},

    -- "Видеть через стены" доступно только админам (true) или всем (false)
    WallsAdminOnly = true,
}

local function AllowedHere()
    local lp = LocalPlayer()
    if not IsValid(lp) then return false end
    if #CONFIG.OnlyFor == 0 then return true end
    local sid, sid64 = lp:SteamID(), lp:SteamID64()
    for _, id in ipairs(CONFIG.OnlyFor) do
        if id == sid or id == sid64 then return true end
    end
    return false
end

local function CanSeeWalls()
    local lp = LocalPlayer()
    if not IsValid(lp) then return false end
    if not CONFIG.WallsAdminOnly then return true end
    return lp:IsAdmin() or lp:IsSuperAdmin()
end

concommand.Add("hpbar_myid", function()
    local lp = LocalPlayer()
    chat.AddText(Color(120, 220, 120), "[HP] ", color_white, "SteamID: " .. lp:SteamID() .. "  |  SteamID64: " .. lp:SteamID64())
    print("[HP] SteamID: " .. lp:SteamID() .. "  SteamID64: " .. lp:SteamID64())
end)

local VERSION = "2.5"

local smoothHP = 100

local cvHud       = CreateClientConVar("hpbar_hud_show", "1", true, false, "Показывать мою полоску ХП", 0, 1)
local cvHideStd   = CreateClientConVar("hpbar_hide_default", "1", true, false, "Скрывать стандартный ХП", 0, 1)
local cvHideArmor  = CreateClientConVar("hpbar_hide_default_armor", "1", true, false, "Скрывать стандартный щит (SUIT), когда включена моя полоска щита", 0, 1)
local cvTrail      = CreateClientConVar("hpbar_trail", "0", true, false, "Белый хвост при уроне", 0, 1)
local cvTextMode   = CreateClientConVar("hpbar_text_mode", "1", true, false, "Текст хп: 0 выкл, 1 100/100, 2 HP 100, 3 100%", 0, 3)
local cvTextBg     = CreateClientConVar("hpbar_text_bg", "1", true, false, "Фон за текстом", 0, 1)
local cvTextBgAlpha = CreateClientConVar("hpbar_text_bg_alpha", "190", true, false, "Прозрачность фона текста (0-255)", 0, 255)
local cvArmorPos   = CreateClientConVar("hpbar_armor_pos", "1", true, false, "Положение щита: 1 под хп, 2 рядом с хп", 1, 2)
local cvArmorTextPos = CreateClientConVar("hpbar_armor_text_pos", "1", true, false, "Текст щита: 1 на полоске, 2 справа", 1, 2)
local cvAmmo       = CreateClientConVar("hpbar_ammo", "1", true, false, "Полоска патронов", 0, 1)
local cvAmmoAlt    = CreateClientConVar("hpbar_ammo_alt", "1", true, false, "Альт-полоска патронов (альт-огонь)", 0, 1)
local cvHideAmmo   = CreateClientConVar("hpbar_hide_default_ammo", "1", true, false, "Скрывать стандартные патроны, когда включена моя полоска", 0, 1)
local cvAmmoPos    = CreateClientConVar("hpbar_ammo_pos", "1", true, false, "Положение патронов: 1 справа внизу, 2 над хп", 1, 2)
local cvAmmoText   = CreateClientConVar("hpbar_ammo_text", "1", true, false, "Текст патронов: 0 выкл, 1 30/90, 2 AMMO 30, 3 100%", 0, 3)
local cvLow        = CreateClientConVar("hpbar_low", "1", true, false, "Красный фон полоски при малом значении", 0, 1)
local cvLowBlink   = CreateClientConVar("hpbar_low_blink", "1", true, false, "Мигание красного фона", 0, 1)
local cvLowPct     = CreateClientConVar("hpbar_low_pct", "25", true, false, "Порог малого значения, %", 5, 50)
local cvWorldText  = CreateClientConVar("hpbar_world_text", "1", true, false, "Текст хп над головами: 0 выкл, 1 100/100, 2 HP 100, 3 100%", 0, 3)
local cvArmor      = CreateClientConVar("hpbar_armor", "1", true, false, "Полоска щита (брони)", 0, 1)
local cvArmorAuto  = CreateClientConVar("hpbar_armor_auto", "1", true, false, "Скрывать полоску щита, когда щита нет", 0, 1)
local cvWorldArmor = CreateClientConVar("hpbar_world_armor", "1", true, false, "Полоска щита над игроками и ботами", 0, 1)
local cvFastNet    = CreateClientConVar("hpbar_fast_net", "0", true, false, "Быстрые сетевые обновления (может уменьшить задержку хп)", 0, 1)
local cvNetBakU    = CreateClientConVar("hpbar_net_bak_u", "0", true, false, "")
local cvNetBakC    = CreateClientConVar("hpbar_net_bak_c", "0", true, false, "")
local cvTextPos    = CreateClientConVar("hpbar_text_pos", "1", true, false, "Положение текста: 1 на полоске, 2 справа, 3 под полоской, 4 на стрелке", 1, 4)
local cvArrowShow   = CreateClientConVar("hpbar_arrow_show", "1", true, false, "Стрелка над полоской", 0, 1)
local cvDeathMe     = CreateClientConVar("hpbar_death_me", "1", true, false, "Иконка смерти: я", 0, 1)
local cvDeathNPC    = CreateClientConVar("hpbar_death_npc", "1", true, false, "Иконка смерти: NPC", 0, 1)
local cvDeathPlayers = CreateClientConVar("hpbar_death_players", "1", true, false, "Иконка смерти: игроки и боты", 0, 1)
local cvDeathBelow  = CreateClientConVar("hpbar_death_arrow_below", "0", true, false, "Стрелка смерти снизу (0 - сверху)", 0, 1)
local cvArrow     = CreateClientConVar("hpbar_arrow", "1", true, false, "Вариант стрелки (1-5)", 1, 5)
local cvDeathShow = CreateClientConVar("hpbar_death_show", "1", true, false, "Показывать иконку при смерти", 0, 1)
local cvDeathIcon = CreateClientConVar("hpbar_death_icon", "3", true, false, "Иконка при смерти (1-15)", 1, 15)

local cvPlayers = CreateClientConVar("hpbar_world_players", "1", true, false, "Полоски над игроками", 0, 1)
local cvBots    = CreateClientConVar("hpbar_world_bots", "1", true, false, "Полоски над ботами", 0, 1)
local cvNPCs    = CreateClientConVar("hpbar_world_npcs", "1", true, false, "Полоски над NPC", 0, 1)
local cvNames   = CreateClientConVar("hpbar_world_names", "1", true, false, "Показывать имена", 0, 1)
local cvWalls   = CreateClientConVar("hpbar_world_walls", "0", true, false, "Видеть через стены", 0, 1)
local cvDeathArrow = CreateClientConVar("hpbar_death_arrow", "1", true, false, "Стрелка над иконкой смерти", 0, 1)
local cvDeathTime = CreateClientConVar("hpbar_death_time", "6", true, false, "Сколько секунд держать иконку над трупом", 1, 30)
local cvDeathForever = CreateClientConVar("hpbar_death_forever", "0", true, false, "Иконка над трупом без времени", 0, 1)
local cvDist    = CreateClientConVar("hpbar_world_dist", "1500", true, false, "Макс. дистанция", 200, 5000)

surface.CreateFont("HPBar_Text", {
    font = "Arial", size = 17, weight = 800, antialias = true,
})
surface.CreateFont("HPBar_TextSmall", {
    font = "Arial", size = 14, weight = 800, antialias = true,
})

-- Фон полоски: красный (и мигающий), когда значение мало. Пустой щит - это норма, поэтому allowZero = false
local function LowBg(frac, allowZero)
    if cvLow:GetBool() and frac <= cvLowPct:GetFloat() / 100 and (frac > 0 or allowZero) then
        local a = cvLowBlink:GetBool() and (0.5 + 0.5 * math.sin(CurTime() * 8)) or 1
        return Color(90 + 150 * a, 10, 10, 200)
    end
    return Color(0, 0, 0, 180)
end

-- Подпись с фоном (если включён) и обводкой; возвращает размер текста
local function DrawLabel(txt, font, tx, ty, ha, va)
    surface.SetFont(font)
    local tw, th = surface.GetTextSize(txt)
    if cvTextBg:GetBool() then
        local bx = (ha == TEXT_ALIGN_CENTER) and (tx - tw / 2) or ((ha == TEXT_ALIGN_RIGHT) and (tx - tw) or tx)
        local by = (va == TEXT_ALIGN_CENTER) and (ty - th / 2) or ((va == TEXT_ALIGN_BOTTOM) and (ty - th) or ty)
        draw.RoundedBox(6, bx - 6, by - 1, tw + 12, th + 2, Color(0, 0, 0, cvTextBgAlpha:GetInt()))
    end
    draw.SimpleTextOutlined(txt, font, tx, ty, color_white, ha, va, 1, Color(0, 0, 0, 220))
    return tw, th
end

-- Вид текста: 1 = 100/100, 2 = HP 100, 3 = 100%
local function FormatHP(hp, maxHP, mode, label)
    if mode == 1 then
        return hp .. "/" .. maxHP
    elseif mode == 2 then
        return (label or "HP") .. " " .. hp
    elseif mode == 3 then
        return math.floor(math.Clamp(hp / maxHP, 0, 1) * 100 + 0.5) .. "%"
    end
end

local function M(name) return Material("custom_hp_bar/" .. name .. ".png", "smooth mips") end

-- base: куда иконка смотрит по умолчанию (градусы против часовой от "вправо")
local ARROWS = {
    [1] = { mat = M("arrow1"), base = 0   },
    [2] = { mat = M("arrow2"), base = 45  },
    [3] = { mat = M("arrow3"), base = 45, keep = true },  -- синяя, свои цвета
    [4] = { mat = M("arrow4"), base = 0, norot = true },   -- молния (не вращается)
    [5] = { mat = M("arrow5"), base = 0, norot = true },   -- ромб (не вращается)
}
local DEATH = {
    [1] = { mat = M("death1") },  -- крестик
    [2] = { mat = M("death2") },  -- удар
    [3] = { mat = M("death3") },  -- призрак
    [4] = { mat = M("death4") },  -- прицел
    [5] = { mat = M("death5") },  -- звезда
    [6] = { mat = M("death6") },  -- рамка
    [7] = { mat = M("death7"), keep = true },  -- череп (свои цвета, без красной заливки)
    [8]  = { mat = M("death8")  },  -- нож
    [9]  = { mat = M("death9")  },  -- треснутый череп
    [10] = { mat = M("death10") },  -- череп
    [11] = { mat = M("death11") },  -- взрыв
    [12] = { mat = M("death12") },  -- хедшот
    [13] = { mat = M("death13") },  -- дезматч (половина черепа)
    [14] = { mat = M("death14") },  -- череп с костями
    [15] = { mat = M("death15") },  -- месть (кулак)
}

local function SwitchArrow()
    local new = cvArrow:GetInt() % #ARROWS + 1
    RunConsoleCommand("hpbar_arrow", tostring(new))
    chat.AddText(Color(120, 220, 120), "[HP] ", color_white, "Стрелка: вариант " .. new)
end
concommand.Add("hpbar_arrow_switch", SwitchArrow)

hook.Add("OnPlayerChat", "CustomHP_ChatCmd", function(ply, text)
    if ply == LocalPlayer() and string.lower(string.Trim(text)) == "!hparrow" then
        SwitchArrow()
        return true
    end
end)

hook.Add("HUDShouldDraw", "CustomHP_HideDefault", function(name)
    if name == "CHudHealth" and cvHideStd:GetBool() and AllowedHere() then return false end
    if name == "CHudBattery" and cvHideArmor:GetBool() and cvArmor:GetBool() and AllowedHere() then return false end
    if name == "CHudAmmo" and cvHideAmmo:GetBool() and cvAmmo:GetBool() and AllowedHere() then return false end
    if name == "CHudSecondaryAmmo" and cvHideAmmo:GetBool() and cvAmmoAlt:GetBool() and AllowedHere() then return false end
end)

-- ===================== ОБЩАЯ ОТРИСОВКА =====================

-- Рисует полоску с хвостом и стрелкой. cx, y — центр по X и верх полоски.
local function DrawBar(x, y, w, h, frac, sfrac, arrowSize)
    local r = math.max(2, h / 4)
    draw.RoundedBox(r + 2, x - 3, y - 3, w + 6, h + 6, LowBg(frac, false))

    if cvTrail:GetBool() and sfrac > frac then
        draw.RoundedBox(r, x, y, w * sfrac, h, Color(255, 255, 255, 90))
    end

    local col = HSVToColor(frac * 120, 0.8, 0.9)
    if frac > 0 then
        draw.RoundedBox(r, x, y, w * frac, h, col)
    end

    if cvArrowShow:GetBool() and arrowSize > 0 then
        local a = ARROWS[math.Clamp(cvArrow:GetInt(), 1, #ARROWS)]
        surface.SetMaterial(a.mat)
        if a.keep then surface.SetDrawColor(255, 255, 255) else surface.SetDrawColor(col) end
        surface.DrawTexturedRectRotated(x + w * frac, y - arrowSize / 2 - 4, arrowSize, arrowSize, a.norot and 0 or (270 - a.base))
    end
end

local function DrawDeathIcon(cx, y, size, alpha)
    alpha = alpha or 1
    local d = DEATH[math.Clamp(cvDeathIcon:GetInt(), 1, #DEATH)]
    local pulse = 190 + math.sin(CurTime() * 4) * 55

    local arrowOn = cvDeathArrow:GetBool()
    local below   = cvDeathBelow:GetBool()
    local asz     = math.max(12, size * 0.55)

    -- Если стрелка снизу, поднимаем иконку, чтобы стрелка встала на прежнее место
    if arrowOn and below then y = y - asz - 4 end

    surface.SetMaterial(d.mat)
    if d.keep then
        surface.SetDrawColor(255, 255, 255, pulse * alpha)
    else
        surface.SetDrawColor(255, 80, 80, pulse * alpha)
    end
    surface.DrawTexturedRect(cx - size / 2, y - size, size, size)

    if arrowOn then
        local a = ARROWS[math.Clamp(cvArrow:GetInt(), 1, #ARROWS)]
        local bob = math.sin(CurTime() * 5) * 3
        surface.SetMaterial(a.mat)
        if a.keep then
            surface.SetDrawColor(255, 255, 255, pulse * alpha)
        else
            surface.SetDrawColor(255, 80, 80, pulse * alpha)
        end
        if below then
            -- снизу, смотрит вверх на иконку
            surface.DrawTexturedRectRotated(cx, y + 2 + asz / 2 - bob, asz, asz, a.norot and 0 or (90 - a.base))
        else
            -- сверху, смотрит вниз на иконку
            surface.DrawTexturedRectRotated(cx, y - size - asz / 2 - 2 + bob, asz, asz, a.norot and 0 or (270 - a.base))
        end
    end
end

-- ===================== СВОЯ ПОЛОСКА =====================

hook.Add("HUDPaint", "CustomHP_Draw", function()
    if not AllowedHere() then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local dead      = not ply:Alive()
    local showBar   = cvHud:GetBool()
    local showDeath = dead and cvDeathShow:GetBool() and cvDeathMe:GetBool()
    if not showBar and not showDeath then return end

    local hp    = dead and 0 or math.max(ply:Health(), 0)
    local maxHP = math.max(ply:GetMaxHealth(), 1)

    smoothHP = Lerp(1 - math.exp(-FrameTime() * 12), smoothHP, hp)

    local w, h = 300, 26
    local aH = 16
    local showArmor   = cvArmor:GetBool()
    local armorBeside = cvArmorPos:GetInt() == 2
    local armorExtra  = (showArmor and not armorBeside) and (aH + 8) or 0
    local x, y = 30, ScrH() - h - 30 - armorExtra
    local frac  = math.Clamp(hp / maxHP, 0, 1)
    local sfrac = math.Clamp(smoothHP / maxHP, 0, 1)

    local mode  = cvTextMode:GetInt()
    local pos   = cvTextPos:GetInt()
    local hpTxt = (showBar and mode > 0) and FormatHP(hp, maxHP, mode) or nil

    -- Считаем текст хп заранее, чтобы щит «рядом» вставал после него
    local rightX = x + w + 10
    if hpTxt and pos == 2 then
        surface.SetFont("HPBar_Text")
        local tw = surface.GetTextSize(hpTxt)
        rightX = rightX + tw + 18
    end

    if showBar then
        DrawBar(x, y, w, h, frac, sfrac, dead and 0 or 24)
    end

    -- Полоска щита: под хп или рядом с хп
    if showBar and showArmor and not dead then
        local armor = math.max(ply:Armor(), 0)
        if armor > 0 or not cvArmorAuto:GetBool() then
            local maxA = ply:GetMaxArmor()
            if maxA <= 0 then maxA = math.max(100, armor) end
            local af = math.Clamp(armor / maxA, 0, 1)

            local aw, ax, ay
            if armorBeside then
                aw, ax, ay = 160, rightX, y + (h - aH) / 2
            else
                aw, ax, ay = w, x, y + h + 8
            end

            draw.RoundedBox(6, ax - 3, ay - 3, aw + 6, aH + 6, LowBg(af, false))
            if af > 0 then
                draw.RoundedBox(4, ax, ay, aw * af, aH, Color(60, 140, 255))
            end

            if mode > 0 then
                local atxt = FormatHP(armor, maxA, mode, "ЩИТ")
                if cvArmorTextPos:GetInt() == 2 then
                    DrawLabel(atxt, "HPBar_TextSmall", ax + aw + 10, ay + aH / 2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                else
                    DrawLabel(atxt, "HPBar_TextSmall", ax + aw / 2, ay + aH / 2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end
        end
    end

    if showDeath then
        DrawDeathIcon(x + w / 2, y - 8, 40)
    end

    if hpTxt then
        local tx, ty, ha, va
        if pos == 2 then
            tx, ty, ha, va = x + w + 10, y + h / 2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER
        elseif pos == 3 then
            tx, ty, ha, va = x + w / 2, y + h + 6 + armorExtra, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP
        elseif pos == 4 then
            local hasArrow = cvArrowShow:GetBool() and not dead
            tx, ty, ha, va = x + w * frac, y - (hasArrow and 32 or 6), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM
        else
            tx, ty, ha, va = x + w / 2, y + h / 2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
        end
        DrawLabel(hpTxt, "HPBar_Text", tx, ty, ha, va)
    end
end)

-- ===================== ПАТРОНЫ =====================

local ammoSeen = {}
local function SeenMax(key, v)
    local m = math.max(ammoSeen[key] or 0, v, 1)
    ammoSeen[key] = m
    return m
end

-- Текст патронов: 1 = обойма/запас, 2 = подпись + обойма, 3 = процент
local function FormatAmmo(clip, reserve, frac, mode, label)
    if mode == 1 then
        if clip >= 0 then return clip .. "/" .. reserve end
        return tostring(reserve)
    elseif mode == 2 then
        return label .. " " .. (clip >= 0 and clip or reserve)
    elseif mode == 3 then
        return math.floor(frac * 100 + 0.5) .. "%"
    end
end

local function DrawSimpleBar(x, y, w, h, frac, col)
    draw.RoundedBox(6, x - 3, y - 3, w + 6, h + 6, LowBg(frac, true))
    if frac > 0 then
        draw.RoundedBox(4, x, y, w * frac, h, col)
    end
end

hook.Add("HUDPaint", "CustomHP_Ammo", function()
    if not cvAmmo:GetBool() or not AllowedHere() then return end
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) then return end

    local pw, ph, ah = 220, 22, 16
    local altOn    = cvAmmoAlt:GetBool()
    local altExtra = altOn and (ah + 8) or 0   -- место под альт-полоску резервируем, чтобы основная не прыгала

    local ax, y0
    if cvAmmoPos:GetInt() == 2 then
        -- над полоской хп (слева)
        local hpTop = ScrH() - 26 - 30 - ((cvArmor:GetBool() and cvArmorPos:GetInt() ~= 2) and 24 or 0)
        ax, y0 = 30, hpTop - 70 - ph - altExtra
    else
        -- справа внизу
        ax, y0 = ScrW() - pw - 30, ScrH() - 30 - ph - altExtra
    end

    local mode = cvAmmoText:GetInt()
    local cls  = wep:GetClass()

    -- Основная полоска: обойма (или запас, если у оружия нет обоймы)
    local pType = wep:GetPrimaryAmmoType()
    local clip  = wep:Clip1()
    if pType >= 0 or clip >= 0 then
        local reserve = (pType >= 0) and ply:GetAmmoCount(pType) or 0
        local value, maxv
        if clip >= 0 then
            value = clip
            maxv  = SeenMax(cls .. "_c1", math.max(wep:GetMaxClip1(), clip))
        else
            value = reserve
            maxv  = SeenMax(cls .. "_r1", reserve)
        end
        local frac = math.Clamp(value / maxv, 0, 1)
        local col  = (frac <= 0.25) and Color(230, 60, 60) or Color(240, 200, 60)
        DrawSimpleBar(ax, y0, pw, ph, frac, col)
        if mode > 0 then
            DrawLabel(FormatAmmo(clip, reserve, frac, mode, "ПАТР"), "HPBar_TextSmall",
                ax + pw / 2, y0 + ph / 2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    -- Альт-полоска: вторичные патроны (альт-огонь)
    if altOn then
        local sType = wep:GetSecondaryAmmoType()
        if sType >= 0 then
            local sClip    = wep:Clip2()
            local sReserve = ply:GetAmmoCount(sType)
            local value, maxv
            if sClip >= 0 then
                value = sClip
                maxv  = SeenMax(cls .. "_c2", math.max(wep:GetMaxClip2(), sClip))
            else
                value = sReserve
                maxv  = SeenMax(cls .. "_r2", sReserve)
            end
            local frac = math.Clamp(value / maxv, 0, 1)
            local col  = (frac <= 0.25) and Color(230, 60, 60) or Color(255, 150, 40)
            local ay   = y0 + ph + 8
            DrawSimpleBar(ax, ay, pw, ah, frac, col)
            if mode > 0 then
                DrawLabel(FormatAmmo(sClip, sReserve, frac, mode, "АЛЬТ"), "HPBar_TextSmall",
                    ax + pw / 2, ay + ah / 2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
    end
end)

-- ===================== ПОЛОСКИ НАД ГОЛОВАМИ =====================

local cache, nextScan = {}, 0
local smooth = setmetatable({}, { __mode = "k" })
local maxSeen = setmetatable({}, { __mode = "k" })

-- Список целей обновляем раз в 0.5 сек, а не каждый кадр
local function Targets()
    if CurTime() > nextScan then
        nextScan = CurTime() + 0.5
        cache = {}
        local lp = LocalPlayer()
        for _, e in ipairs(ents.GetAll()) do
            if e ~= lp and (e:IsPlayer() or e:IsNPC() or e:IsNextBot()) then
                cache[#cache + 1] = e
            end
        end
    end
    return cache
end

-- Метки смерти: иконка над трупом NPC
local marks = {}
local deadMarked = setmetatable({}, { __mode = "k" })

local function AddMark(pos, ent)
    for _, m in ipairs(marks) do
        if CurTime() - m.t < 2 and m.pos:DistToSqr(pos) < 150 * 150 then
            if ent then m.ent = ent end
            return
        end
    end
    marks[#marks + 1] = { pos = pos, ent = ent, t = CurTime() }
    if #marks > 40 then table.remove(marks, 1) end
end

hook.Add("PostCleanupMap", "CustomHP_ClearMarks", function() marks = {} end)

-- Тест: поставить иконку смерти туда, куда смотришь (консоль: hpbar_test)
concommand.Add("hpbar_test", function()
    local tr = LocalPlayer():GetEyeTrace()
    AddMark(tr.HitPos + Vector(0, 0, 30), nil)
end)

-- Последняя известная позиция NPC. Если NPC пропал (убит и заменён трупом) - ставим метку
local lastPos = setmetatable({}, { __mode = "k" })

hook.Add("EntityRemoved", "CustomHP_NPCRemoved", function(ent, fullUpdate)
    if fullUpdate then return end
    local p = lastPos[ent]
    if not p then return end
    lastPos[ent] = nil
    if EyePos():Distance(p) <= cvDist:GetFloat() then
        AddMark(p, nil)
    end
end)

-- Клиентский рэгдолл, который игра создаёт при смерти NPC
hook.Add("OnEntityCreated", "CustomHP_Ragdoll", function(ent)
    timer.Simple(0, function()
        if IsValid(ent) and ent:GetClass() == "class C_ClientRagdoll" then
            AddMark(ent:WorldSpaceCenter(), ent)
        end
    end)
end)

local function Allowed(e)
    if e:IsPlayer() then
        if e:IsBot() then return cvBots:GetBool() end
        return cvPlayers:GetBool()
    end
    return cvNPCs:GetBool()
end

hook.Add("HUDPaint", "CustomHP_World", function()
    local lp = LocalPlayer()
    if not IsValid(lp) or not lp:Alive() or not AllowedHere() then return end

    local eye     = EyePos()
    local maxDist = cvDist:GetFloat()
    local walls   = cvWalls:GetBool() and CanSeeWalls()
    local names   = cvNames:GetBool()
    local ft      = 1 - math.exp(-FrameTime() * 12)

    for _, e in ipairs(Targets()) do
        if not IsValid(e) then continue end
        if not e:IsPlayer() and e:Health() > 0 then lastPos[e] = e:WorldSpaceCenter() end
        if not Allowed(e) or e:GetNoDraw() then continue end

        local isPly = e:IsPlayer()
        local dead  = isPly and not e:Alive()
        local hp    = e:Health()

        if not isPly and hp <= 0 then
            if not deadMarked[e] then
                deadMarked[e] = true
                AddMark(e:WorldSpaceCenter(), nil)
            end
            continue
        end
        if dead and not (cvDeathShow:GetBool() and cvDeathPlayers:GetBool()) then continue end

        local top  = e:GetPos() + Vector(0, 0, e:OBBMaxs().z + 14)
        local dist = eye:Distance(top)
        if dist > maxDist then continue end

        local sp = top:ToScreen()
        if not sp.visible then continue end

        if not walls then
            local tr = util.TraceLine({
                start  = eye,
                endpos = e:WorldSpaceCenter(),
                filter = { lp, e },
                mask   = MASK_OPAQUE,
            })
            if tr.Hit then continue end
        end

        local sc = math.Clamp(1.25 - dist / maxDist, 0.5, 1)
        local w, h = 80 * sc, 9 * sc
        local x, y = sp.x - w / 2, sp.y

        local nameY = y + h + 5

        if dead then
            DrawDeathIcon(sp.x, y, 28 * sc + 8)
        else
            local maxHP = math.max(e:GetMaxHealth(), hp, maxSeen[e] or 0, 1)
            maxSeen[e] = maxHP

            smooth[e] = Lerp(ft, smooth[e] or hp, hp)
            local frac  = math.Clamp(hp / maxHP, 0, 1)
            local sfrac = math.Clamp(smooth[e] / maxHP, 0, 1)

            DrawBar(x, y, w, h, frac, sfrac, 14 * sc + 4)

            local belowY = y + h + 4
            if isPly and cvWorldArmor:GetBool() then
                local armor = e:Armor()
                if armor > 0 then
                    local maxA = e:GetMaxArmor()
                    if maxA <= 0 then maxA = math.max(100, armor) end
                    local ah = math.max(3, h * 0.45)
                    local ay = y + h + 3
                    draw.RoundedBox(2, x - 2, ay - 1, w + 4, ah + 2, LowBg(math.Clamp(armor / maxA, 0, 1), false))
                    draw.RoundedBox(2, x, ay, w * math.Clamp(armor / maxA, 0, 1), ah, Color(60, 140, 255))
                    belowY = ay + ah + 3
                    nameY = belowY + 1
                end
            end

            local wm = cvWorldText:GetInt()
            if wm > 0 then
                local txt = FormatHP(hp, maxHP, wm)
                local ty = belowY
                local _, th = DrawLabel(txt, "HPBar_TextSmall", sp.x, ty, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
                nameY = ty + th + 3
            end
        end

        if names then
            local label = isPly and e:Nick() or language.GetPhrase(e:GetClass())
            draw.SimpleTextOutlined(label, "DermaDefault", sp.x, nameY,
                color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))
        end
    end

    -- Иконки смерти над трупами NPC
    if cvDeathShow:GetBool() and cvDeathNPC:GetBool() and cvNPCs:GetBool() then
        local now, dur = CurTime(), cvDeathTime:GetFloat()
        local forever  = cvDeathForever:GetBool()
        for i = #marks, 1, -1 do
            local m = marks[i]
            local age = now - m.t
            local gone = false
            if m.ent ~= nil and not IsValid(m.ent) and forever then gone = true end  -- труп исчез
            if gone or (not forever and age > dur) then
                table.remove(marks, i)
            else
                if IsValid(m.ent) then m.pos = m.ent:WorldSpaceCenter() end
                local pos  = m.pos + Vector(0, 0, 18)
                local dist = eye:Distance(pos)
                if dist <= maxDist then
                    local sp = pos:ToScreen()
                    local ok = sp.visible
                    if ok and not walls then
                        -- труп не должен перекрывать сам себя: фильтруем его и допускаем попадание рядом с целью
                        local tr = util.TraceLine({ start = eye, endpos = pos, filter = { lp, m.ent }, mask = MASK_OPAQUE })
                        ok = (not tr.Hit) or tr.HitPos:DistToSqr(pos) < 60 * 60
                    end
                    if ok then
                        local sc = math.Clamp(1.25 - dist / maxDist, 0.5, 1)
                        local alpha = forever and 1 or math.Clamp(dur - age, 0, 1)
                        DrawDeathIcon(sp.x, sp.y, 28 * sc + 8, alpha)
                    end
                end
            end
        end
    end
end)

-- Быстрые сетевые обновления: поднимает cl_updaterate/cl_cmdrate, при выключении возвращает прежние
local function ApplyFastNet()
    if cvFastNet:GetBool() then
        if cvNetBakU:GetInt() == 0 then
            local u, c = GetConVar("cl_updaterate"), GetConVar("cl_cmdrate")
            if u and c then
                RunConsoleCommand("hpbar_net_bak_u", tostring(u:GetInt()))
                RunConsoleCommand("hpbar_net_bak_c", tostring(c:GetInt()))
            end
        end
        RunConsoleCommand("cl_updaterate", "66")
        RunConsoleCommand("cl_cmdrate", "66")
    else
        local u, c = cvNetBakU:GetInt(), cvNetBakC:GetInt()
        if u > 0 then RunConsoleCommand("cl_updaterate", tostring(u)) end
        if c > 0 then RunConsoleCommand("cl_cmdrate", tostring(c)) end
        RunConsoleCommand("hpbar_net_bak_u", "0")
        RunConsoleCommand("hpbar_net_bak_c", "0")
    end
end

cvars.AddChangeCallback("hpbar_fast_net", function()
    timer.Simple(0, ApplyFastNet)
end, "CustomHP_FastNet")

hook.Add("InitPostEntity", "CustomHP_FastNetInit", function()
    if cvFastNet:GetBool() then ApplyFastNet() end
end)

-- Диагностика задержки: hpbar_lag
concommand.Add("hpbar_lag", function()
    chat.AddText(Color(120, 220, 120), "[HP] ", color_white, "v" .. VERSION)
    local lp = LocalPlayer()
    local u = GetConVar("cl_updaterate")
    chat.AddText(Color(120, 220, 120), "[HP] ", color_white,
        string.format("Пинг: %d мс | FPS: %d | cl_updaterate: %d", lp:Ping(), math.floor(1 / math.max(RealFrameTime(), 0.001)), u and u:GetInt() or 0))
end)

-- ===================== НАСТРОЙКИ =====================

local function IconPicker(cvar, items, rotFn)
    local perRow = math.min(#items, 4)
    local rows   = math.ceil(#items / perRow)
    local pnl = vgui.Create("DPanel")
    pnl:SetTall(rows * 64 + (rows - 1) * 6)
    pnl.Paint = nil
    pnl.btns = {}

    for i, it in ipairs(items) do
        local b = vgui.Create("DButton", pnl)
        b:SetText("")
        b.Paint = function(s, bw, bh)
            local sel = cvar:GetInt() == i
            draw.RoundedBox(6, 0, 0, bw, bh, sel and Color(70, 150, 70) or Color(55, 55, 55))
            if s:IsHovered() and not sel then draw.RoundedBox(6, 0, 0, bw, bh, Color(255, 255, 255, 25)) end
            local sz = bh - 20
            surface.SetMaterial(it.mat)
            surface.SetDrawColor(255, 255, 255)
            surface.DrawTexturedRectRotated(bw / 2, bh / 2, sz, sz, rotFn and rotFn(it) or 0)
        end
        b.DoClick = function() RunConsoleCommand(cvar:GetName(), tostring(i)) end
        pnl.btns[i] = b
    end

    pnl.PerformLayout = function(s, pw, ph)
        local gap = 6
        local bw = math.floor((pw - gap * (perRow - 1)) / perRow)
        for i, b in ipairs(s.btns) do
            local col = (i - 1) % perRow
            local row = math.floor((i - 1) / perRow)
            b:SetPos(col * (bw + gap), row * (64 + gap))
            b:SetSize(bw, 64)
        end
    end
    return pnl
end

-- Ряд текстовых кнопок: { подпись, значение }
local function TextPicker(cvar, options, perRow)
    perRow = perRow or #options
    local rows = math.ceil(#options / perRow)
    local pnl = vgui.Create("DPanel")
    pnl:SetTall(rows * 36 + (rows - 1) * 6)
    pnl.Paint = nil
    pnl.btns = {}

    for i, opt in ipairs(options) do
        local b = vgui.Create("DButton", pnl)
        b:SetText("")
        b.Paint = function(self, bw, bh)
            local sel = cvar:GetInt() == opt[2]
            draw.RoundedBox(6, 0, 0, bw, bh, sel and Color(70, 150, 70) or Color(55, 55, 55))
            if self:IsHovered() and not sel then draw.RoundedBox(6, 0, 0, bw, bh, Color(255, 255, 255, 25)) end
            draw.SimpleText(opt[1], "DermaDefaultBold", bw / 2, bh / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        b.DoClick = function() RunConsoleCommand(cvar:GetName(), tostring(opt[2])) end
        pnl.btns[i] = b
    end

    pnl.PerformLayout = function(self, pw, ph)
        local gap = 6
        local bw = math.floor((pw - gap * (perRow - 1)) / perRow)
        for i, b in ipairs(self.btns) do
            local col = (i - 1) % perRow
            local row = math.floor((i - 1) / perRow)
            b:SetPos(col * (bw + gap), row * (36 + gap))
            b:SetSize(bw, 36)
        end
    end
    return pnl
end

hook.Add("PopulateToolMenu", "CustomHP_Settings", function()
    spawnmenu.AddToolMenuOption("Utilities", "User", "hpbar_settings", "Полоска ХП", "", "", function(panel)
        panel:ClearControls()
        panel:Help("v" .. VERSION)

        if not AllowedHere() then
            panel:Help("Недоступно: скрипт включён только для определённых игроков.")
            return
        end

        -- Моя полоска
        panel:Help("— МОЯ ПОЛОСКА —")
        panel:CheckBox("Показывать мою полоску ХП", "hpbar_hud_show")
        panel:CheckBox("Показывать полоску щита", "hpbar_armor")
        panel:CheckBox("Скрывать щит, когда его нет", "hpbar_armor_auto")
        panel:Help("Положение щита:")
        panel:AddItem(TextPicker(cvArmorPos, { { "Под хп", 1 }, { "Рядом с хп", 2 } }))
        panel:Help("Текст щита:")
        panel:AddItem(TextPicker(cvArmorTextPos, { { "На полоске", 1 }, { "Справа", 2 } }))
        panel:CheckBox("Скрывать стандартный ХП", "hpbar_hide_default")
        panel:CheckBox("Скрывать стандартный щит (SUIT)", "hpbar_hide_default_armor")
        panel:CheckBox("Хвост при уроне (белый, плавный)", "hpbar_trail")
        panel:CheckBox("Быстрые сетевые обновления (меньше задержка хп)", "hpbar_fast_net")
        panel:Help("Текст хп на полоске:")
        panel:AddItem(TextPicker(cvTextMode, { { "Выкл", 0 }, { "100/100", 1 }, { "HP 100", 2 }, { "100%", 3 } }))
        panel:CheckBox("Фон за текстом", "hpbar_text_bg")
        panel:NumSlider("Прозрачность фона текста", "hpbar_text_bg_alpha", 0, 255, 0)
        panel:Help("Где показывать текст:")
        panel:AddItem(TextPicker(cvTextPos, { { "На полоске", 1 }, { "Справа", 2 }, { "Под полоской", 3 }, { "На стрелке", 4 } }, 2))
        panel:CheckBox("Стрелка над полоской", "hpbar_arrow_show")
        panel:Help("Вид стрелки:")
        panel:AddItem(IconPicker(cvArrow, ARROWS, function(it) return it.norot and 0 or -it.base end))

        -- Иконка смерти
        panel:Help("")
        panel:Help("— ИКОНКА СМЕРТИ —")
        panel:CheckBox("Показывать иконку при смерти (общий)", "hpbar_death_show")
        panel:CheckBox("Для меня", "hpbar_death_me")
        panel:CheckBox("Для NPC", "hpbar_death_npc")
        panel:CheckBox("Для игроков и ботов", "hpbar_death_players")
        panel:Help("Вид иконки:")
        panel:AddItem(IconPicker(cvDeathIcon, DEATH))
        panel:CheckBox("Стрелка у иконки смерти", "hpbar_death_arrow")
        panel:CheckBox("Стрелка снизу (иначе сверху)", "hpbar_death_arrow_below")
        panel:CheckBox("Иконка над трупом без времени", "hpbar_death_forever")
        panel:NumSlider("Иконка над трупом, сек", "hpbar_death_time", 1, 30, 0)
        panel:Help("")
        panel:Help("— ПАТРОНЫ —")
        panel:CheckBox("Показывать полоску патронов", "hpbar_ammo")
        panel:CheckBox("Альт-полоска патронов", "hpbar_ammo_alt")
        panel:CheckBox("Скрывать стандартные патроны", "hpbar_hide_default_ammo")
        panel:Help("Положение патронов:")
        panel:AddItem(TextPicker(cvAmmoPos, { { "Справа внизу", 1 }, { "Над хп", 2 } }))
        panel:Help("Текст патронов:")
        panel:AddItem(TextPicker(cvAmmoText, { { "Выкл", 0 }, { "30/90", 1 }, { "ПАТР 30", 2 }, { "100%", 3 } }))
        panel:Help("")
        panel:Help("— МАЛО ХП / ЩИТА / ПАТРОНОВ —")
        panel:CheckBox("Красный фон при малом значении", "hpbar_low")
        panel:CheckBox("Мигание", "hpbar_low_blink")
        panel:NumSlider("Порог, %", "hpbar_low_pct", 5, 50, 0)

        -- Над головами
        panel:Help("")
        panel:Help("— ПОЛОСКИ НАД ГОЛОВАМИ —")
        panel:CheckBox("Игроки", "hpbar_world_players")
        panel:CheckBox("Боты", "hpbar_world_bots")
        panel:CheckBox("NPC", "hpbar_world_npcs")
        panel:CheckBox("Показывать имена", "hpbar_world_names")
        panel:CheckBox("Щит над игроками и ботами", "hpbar_world_armor")
        panel:Help("Текст хп над головами:")
        panel:AddItem(TextPicker(cvWorldText, { { "Выкл", 0 }, { "100/100", 1 }, { "HP 100", 2 }, { "100%", 3 } }))
        if CanSeeWalls() then
            panel:CheckBox("Видеть через стены (админ)", "hpbar_world_walls")
        else
            panel:Help("Видеть через стены: только для админов.")
        end
        panel:NumSlider("Дистанция", "hpbar_world_dist", 200, 5000, 0)
    end)
end)
